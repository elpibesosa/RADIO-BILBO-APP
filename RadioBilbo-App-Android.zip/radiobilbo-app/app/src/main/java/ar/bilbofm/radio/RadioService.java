package ar.bilbofm.radio;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

/**
 * Reproduce el streaming de Radio Bilbo en segundo plano.
 * Solo se conecta a la URL del streaming: no abre páginas ni enlaces.
 */
@SuppressWarnings("deprecation")
public class RadioService extends Service implements AudioManager.OnAudioFocusChangeListener {

    /** Dirección del streaming. Si algún día cambia el proveedor, se cambia solo esta línea. */
    static final String STREAM_URL =
            "https://uk16freenew.listen2myradio.com/live.mp3?typeportmount=s1_15701_stream_113140693";

    static final String ACTION_PLAY = "ar.bilbofm.radio.PLAY";
    static final String ACTION_STOP = "ar.bilbofm.radio.STOP";
    static final String ACTION_ESTADO = "ar.bilbofm.radio.ESTADO";

    static final int ESTADO_DETENIDO = 0;
    static final int ESTADO_CONECTANDO = 1;
    static final int ESTADO_SONANDO = 2;
    static final int ESTADO_PAUSA = 3;
    static final int ESTADO_SIN_RED = 4;
    static final int ESTADO_ERROR = 5;

    /** Estado actual; la pantalla lo consulta al abrirse. */
    static volatile int estado = ESTADO_DETENIDO;

    private static final String CANAL = "radio_bilbo_en_vivo";
    private static final int NOTIF_ID = 915;
    private static final int MAX_REINTENTOS = 5;
    private static final long ESPERA_REINTENTO_MS = 3000;
    private static final long ESPERA_CONEXION_MS = 20000;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private MediaPlayer player;
    private AudioManager audio;
    private WifiManager.WifiLock wifiLock;
    private boolean quiereSonar = false;
    private boolean focoPerdidoTemporal = false;
    private int reintentos = 0;

    private final Runnable reiniciar = new Runnable() {
        @Override
        public void run() {
            iniciarReproduccion();
        }
    };

    private final Runnable tiempoAgotado = new Runnable() {
        @Override
        public void run() {
            if (quiereSonar && estado == ESTADO_CONECTANDO) {
                reintentarOFallar();
            }
        }
    };

    /** Si se desconectan los auriculares, la radio se detiene. */
    private final BroadcastReceiver auricularesDesconectados = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (quiereSonar) {
                detener();
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        crearCanalNotificacion();
        IntentFilter filtro = new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(auricularesDesconectados, filtro, Context.RECEIVER_EXPORTED);
        } else {
            registerReceiver(auricularesDesconectados, filtro);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String accion = intent != null ? intent.getAction() : null;

        if (ACTION_STOP.equals(accion)) {
            detener();
            return START_NOT_STICKY;
        }
        if (intent == null) {
            stopSelf();
            return START_NOT_STICKY;
        }

        // Android exige mostrar la notificación enseguida cuando se inicia un servicio en primer plano
        iniciarPrimerPlano("Conectando…");
        reintentos = 0;
        focoPerdidoTemporal = false;
        iniciarReproduccion();
        return START_NOT_STICKY;
    }

    // ------------------------------------------------------------------
    // Reproducción
    // ------------------------------------------------------------------

    private void iniciarReproduccion() {
        handler.removeCallbacks(reiniciar);
        quiereSonar = true;

        if (!hayRed()) {
            fallar(ESTADO_SIN_RED);
            return;
        }

        liberarPlayer();
        cambiarEstado(ESTADO_CONECTANDO);
        audio.requestAudioFocus(this, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);

        try {
            final MediaPlayer mp = new MediaPlayer();
            player = mp;
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build());
            mp.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK);
            mp.setDataSource(STREAM_URL);

            mp.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer m) {
                    if (m != player || !quiereSonar) return;
                    handler.removeCallbacks(tiempoAgotado);
                    reintentos = 0;
                    m.start();
                    cambiarEstado(ESTADO_SONANDO);
                }
            });
            mp.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override
                public boolean onError(MediaPlayer m, int what, int extra) {
                    if (m == player) reintentarOFallar();
                    return true;
                }
            });
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer m) {
                    if (m == player) reintentarOFallar();
                }
            });
            mp.setOnInfoListener(new MediaPlayer.OnInfoListener() {
                @Override
                public boolean onInfo(MediaPlayer m, int what, int extra) {
                    if (m != player || !quiereSonar) return false;
                    if (what == MediaPlayer.MEDIA_INFO_BUFFERING_START) {
                        cambiarEstado(ESTADO_CONECTANDO);
                    } else if (what == MediaPlayer.MEDIA_INFO_BUFFERING_END) {
                        cambiarEstado(ESTADO_SONANDO);
                    }
                    return true;
                }
            });

            tomarWifiLock();
            handler.postDelayed(tiempoAgotado, ESPERA_CONEXION_MS);
            mp.prepareAsync();
        } catch (Exception e) {
            reintentarOFallar();
        }
    }

    private void reintentarOFallar() {
        if (!quiereSonar) return;
        liberarPlayer();
        if (reintentos < MAX_REINTENTOS && hayRed()) {
            reintentos++;
            cambiarEstado(ESTADO_CONECTANDO);
            handler.postDelayed(reiniciar, ESPERA_REINTENTO_MS);
        } else {
            fallar(hayRed() ? ESTADO_ERROR : ESTADO_SIN_RED);
        }
    }

    private void fallar(int estadoError) {
        quiereSonar = false;
        handler.removeCallbacksAndMessages(null);
        liberarPlayer();
        soltarWifiLock();
        audio.abandonAudioFocus(this);
        cambiarEstado(estadoError);
        stopForeground(true);
        stopSelf();
    }

    private void detener() {
        quiereSonar = false;
        focoPerdidoTemporal = false;
        handler.removeCallbacksAndMessages(null);
        liberarPlayer();
        soltarWifiLock();
        audio.abandonAudioFocus(this);
        cambiarEstado(ESTADO_DETENIDO);
        stopForeground(true);
        stopSelf();
    }

    private void liberarPlayer() {
        handler.removeCallbacks(tiempoAgotado);
        MediaPlayer mp = player;
        player = null;
        if (mp != null) {
            mp.setOnPreparedListener(null);
            mp.setOnErrorListener(null);
            mp.setOnCompletionListener(null);
            mp.setOnInfoListener(null);
            try {
                mp.release();
            } catch (Exception ignorado) {
                // nada que hacer
            }
        }
    }

    // ------------------------------------------------------------------
    // Foco de audio (llamadas, otras apps de música)
    // ------------------------------------------------------------------

    @Override
    public void onAudioFocusChange(int cambio) {
        switch (cambio) {
            case AudioManager.AUDIOFOCUS_LOSS:
                // otra app tomó el audio: dejamos de reproducir
                if (quiereSonar) detener();
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                // por ejemplo una llamada: pausamos y reconectamos al volver
                if (quiereSonar) {
                    focoPerdidoTemporal = true;
                    handler.removeCallbacks(reiniciar);
                    liberarPlayer();
                    cambiarEstado(ESTADO_PAUSA);
                }
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                if (player != null) player.setVolume(0.2f, 0.2f);
                break;
            case AudioManager.AUDIOFOCUS_GAIN:
                if (player != null) player.setVolume(1f, 1f);
                if (focoPerdidoTemporal && quiereSonar) {
                    focoPerdidoTemporal = false;
                    reintentos = 0;
                    iniciarReproduccion();
                }
                break;
            default:
                break;
        }
    }

    // ------------------------------------------------------------------
    // Estado, red y bloqueo de Wi-Fi
    // ------------------------------------------------------------------

    private void cambiarEstado(int nuevo) {
        estado = nuevo;
        Intent aviso = new Intent(ACTION_ESTADO);
        aviso.setPackage(getPackageName());
        sendBroadcast(aviso);

        if (quiereSonar) {
            String texto;
            if (nuevo == ESTADO_SONANDO) texto = "En vivo · 91.5 FM";
            else if (nuevo == ESTADO_PAUSA) texto = "En pausa";
            else texto = "Conectando…";
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(NOTIF_ID, construirNotificacion(texto));
        }
    }

    private boolean hayRed() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        NetworkInfo info = cm.getActiveNetworkInfo();
        return info != null && info.isConnected();
    }

    /** Mantiene el Wi-Fi activo mientras suena la radio con la pantalla apagada. */
    private void tomarWifiLock() {
        try {
            if (wifiLock == null) {
                WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                if (wm == null) return;
                wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "RadioBilbo:wifi");
                wifiLock.setReferenceCounted(false);
            }
            if (!wifiLock.isHeld()) wifiLock.acquire();
        } catch (Exception ignorado) {
            // si no se puede, la radio igual funciona
        }
    }

    private void soltarWifiLock() {
        try {
            if (wifiLock != null && wifiLock.isHeld()) wifiLock.release();
        } catch (Exception ignorado) {
            // nada que hacer
        }
    }

    // ------------------------------------------------------------------
    // Notificación
    // ------------------------------------------------------------------

    private void crearCanalNotificacion() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel canal = new NotificationChannel(
                    CANAL, "Radio Bilbo en vivo", NotificationManager.IMPORTANCE_LOW);
            canal.setShowBadge(false);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(canal);
        }
    }

    private void iniciarPrimerPlano(String texto) {
        Notification n = construirNotificacion(texto);
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    private Notification construirNotificacion(String texto) {
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;

        Intent abrir = new Intent(this, MainActivity.class);
        abrir.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pAbrir = PendingIntent.getActivity(this, 0, abrir, flags);

        Intent parar = new Intent(this, RadioService.class).setAction(ACTION_STOP);
        PendingIntent pParar = PendingIntent.getService(this, 1, parar, flags);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CANAL)
                : new Notification.Builder(this);
        b.setSmallIcon(R.drawable.ic_stat_radio)
                .setContentTitle("Radio Bilbo 91.5 FM")
                .setContentText(texto)
                .setContentIntent(pAbrir)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .addAction(android.R.drawable.ic_media_pause, "Detener", pParar)
                .setStyle(new Notification.MediaStyle().setShowActionsInCompactView(0));
        if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_LOW);
        return b.build();
    }

    // ------------------------------------------------------------------

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        liberarPlayer();
        soltarWifiLock();
        try {
            unregisterReceiver(auricularesDesconectados);
        } catch (Exception ignorado) {
            // ya estaba desregistrado
        }
        if (estado == ESTADO_SONANDO || estado == ESTADO_CONECTANDO) {
            estado = ESTADO_DETENIDO;
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
