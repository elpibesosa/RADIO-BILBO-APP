package ar.bilbofm.radio;

import android.Manifest;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

/** Pantalla única: logo, botón de play/pausa y estado. Sin enlaces ni navegador. */
public class MainActivity extends Activity {

    private ImageView logo;
    private ImageButton boton;
    private TextView textoEstado;
    private ObjectAnimator giro;

    private final BroadcastReceiver receptor = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            actualizarPantalla();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        logo = (ImageView) findViewById(R.id.logo);
        boton = (ImageButton) findViewById(R.id.btnPlay);
        textoEstado = (TextView) findViewById(R.id.estado);

        // El logo gira suave (una vuelta cada 40 segundos) mientras suena la radio,
        // alrededor del centro real del círculo.
        logo.post(new Runnable() {
            @Override
            public void run() {
                logo.setPivotX(logo.getWidth() * 0.5135f);
                logo.setPivotY(logo.getHeight() * 0.4886f);
                giro = ObjectAnimator.ofFloat(logo, View.ROTATION, 0f, 360f);
                giro.setDuration(40000);
                giro.setInterpolator(new LinearInterpolator());
                giro.setRepeatCount(ValueAnimator.INFINITE);
                actualizarPantalla();
            }
        });

        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alternar();
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter filtro = new IntentFilter(RadioService.ACTION_ESTADO);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receptor, filtro, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(receptor, filtro);
        }
        actualizarPantalla();
    }

    @Override
    protected void onStop() {
        super.onStop();
        try {
            unregisterReceiver(receptor);
        } catch (Exception ignorado) {
            // ya estaba desregistrado
        }
        girar(false); // sin pantalla visible no hace falta animar
    }

    private void alternar() {
        int e = RadioService.estado;
        if (e == RadioService.ESTADO_SONANDO || e == RadioService.ESTADO_CONECTANDO) {
            startService(new Intent(this, RadioService.class).setAction(RadioService.ACTION_STOP));
        } else {
            pedirPermisoNotificaciones();
            Intent i = new Intent(this, RadioService.class).setAction(RadioService.ACTION_PLAY);
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(i);
            } else {
                startService(i);
            }
        }
    }

    /** Android 13+ pide permiso para mostrar la notificación de "Radio Bilbo en vivo". */
    private void pedirPermisoNotificaciones() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    private void actualizarPantalla() {
        int e = RadioService.estado;
        boolean activo = (e == RadioService.ESTADO_SONANDO || e == RadioService.ESTADO_CONECTANDO);

        boton.setImageResource(activo ? R.drawable.ic_pause : R.drawable.ic_play);
        boton.setContentDescription(activo ? "Detener la radio" : "Escuchar Radio Bilbo en vivo");

        switch (e) {
            case RadioService.ESTADO_CONECTANDO:
                textoEstado.setText("Conectando…");
                break;
            case RadioService.ESTADO_SONANDO:
                textoEstado.setText("Estás escuchando Radio Bilbo en vivo");
                break;
            case RadioService.ESTADO_PAUSA:
                textoEstado.setText("En pausa");
                break;
            case RadioService.ESTADO_SIN_RED:
                textoEstado.setText("Sin conexión a internet.\nConectate al Wi‑Fi y probá de nuevo.");
                break;
            case RadioService.ESTADO_ERROR:
                String motivo = RadioService.ultimoError;
                textoEstado.setText("No pudimos conectar con la radio.\nProbá de nuevo en un momento."
                        + (motivo != null ? "\n(" + motivo + ")" : ""));
                break;
            default:
                textoEstado.setText("Tocá para escuchar");
                break;
        }
        girar(e == RadioService.ESTADO_SONANDO);
    }

    private void girar(boolean activar) {
        if (giro == null) return;
        if (activar) {
            if (!giro.isStarted()) {
                giro.start();
            } else if (giro.isPaused()) {
                giro.resume();
            }
        } else if (giro.isRunning()) {
            giro.pause();
        }
    }
}
